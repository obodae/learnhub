export interface Module {
  id: string;
  title: string;
  description: string;
  creator_id: string;
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  thumbnail_url?: string;
  content: ModuleContent[];
  created_at: Date;
  updated_at: Date;
  is_published: boolean;
  enrollment_count: number;
}

export interface ModuleContent {
  id: string;
  module_id: string;
  lesson_number: number;
  title: string;
  description: string;
  content_type: 'video' | 'text' | 'code' | 'quiz';
  content_data: string;
  duration_minutes?: number;
  resources?: string[];
}

export interface ModuleEnrollment {
  id: string;
  user_id: string;
  module_id: string;
  progress_percentage: number;
  completed_lessons: string[];
  enrolled_at: Date;
  completed_at?: Date;
}
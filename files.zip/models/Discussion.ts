export interface Discussion {
  id: string;
  module_id?: string;
  repo_id?: string;
  creator_id: string;
  title: string;
  description: string;
  category: 'question' | 'discussion' | 'feedback' | 'announcement';
  created_at: Date;
  updated_at: Date;
  view_count: number;
  replies_count: number;
  is_resolved?: boolean;
}

export interface DiscussionReply {
  id: string;
  discussion_id: string;
  user_id: string;
  content: string;
  is_accepted_answer?: boolean;
  created_at: Date;
  updated_at: Date;
  reply_count: number;
}
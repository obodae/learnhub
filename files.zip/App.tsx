import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Modules from './pages/Modules';
import CodeRepos from './pages/CodeRepos';
import Discussions from './pages/Discussions';
import Dashboard from './pages/Dashboard';
import './styles/App.css';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(
    !!localStorage.getItem('token')
  );

  return (
    <Router>
      <Navbar isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated} />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/modules" element={<Modules />} />
        <Route path="/repos" element={<CodeRepos />} />
        <Route path="/discussions" element={<Discussions />} />
        {isAuthenticated && <Route path="/dashboard" element={<Dashboard />} />}
      </Routes>
    </Router>
  );
};

export default App;
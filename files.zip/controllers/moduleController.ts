import { Request, Response } from 'express';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';

export class ModuleController {
  constructor(private pool: Pool) {}

  async createModule(req: Request, res: Response) {
    try {
      const { title, description, category, difficulty } = req.body;
      const creator_id = (req as any).user.userId;

      const module_id = uuidv4();

      await this.pool.query(
        `INSERT INTO modules (id, title, description, creator_id, category, difficulty)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [module_id, title, description, creator_id, category, difficulty]
      );

      res.status(201).json({
        message: 'Module created successfully',
        module_id,
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create module' });
    }
  }

  async getModules(req: Request, res: Response) {
    try {
      const { category, difficulty, search } = req.query;

      let query = 'SELECT * FROM modules WHERE is_published = true';
      const params: any[] = [];

      if (category) {
        query += ' AND category = $' + (params.length + 1);
        params.push(category);
      }

      if (difficulty) {
        query += ' AND difficulty = $' + (params.length + 1);
        params.push(difficulty);
      }

      if (search) {
        query += ' AND (title ILIKE $' + (params.length + 1) + ' OR description ILIKE $' + (params.length + 1) + ')';
        params.push(`%${search}%`);
      }

      const result = await this.pool.query(query, params);

      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch modules' });
    }
  }

  async addLessonContent(req: Request, res: Response) {
    try {
      const { module_id } = req.params;
      const { lesson_number, title, content_type, content_data } = req.body;

      const content_id = uuidv4();

      await this.pool.query(
        `INSERT INTO module_content (id, module_id, lesson_number, title, content_type, content_data)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [content_id, module_id, lesson_number, title, content_type, content_data]
      );

      res.status(201).json({
        message: 'Lesson content added successfully',
        content_id,
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to add lesson content' });
    }
  }
}
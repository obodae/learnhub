import { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';

export class AuthController {
  constructor(private pool: Pool) {}

  async register(req: Request, res: Response) {
    try {
      const { email, username, password, full_name } = req.body;

      // Validation
      if (!email || !username || !password || !full_name) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      // Check if user exists
      const userExists = await this.pool.query(
        'SELECT id FROM users WHERE email = $1 OR username = $2',
        [email, username]
      );

      if (userExists.rows.length > 0) {
        return res.status(409).json({ error: 'User already exists' });
      }

      // Hash password
      const password_hash = await bcrypt.hash(password, 10);
      const user_id = uuidv4();

      // Create user
      await this.pool.query(
        'INSERT INTO users (id, email, username, password_hash, full_name) VALUES ($1, $2, $3, $4, $5)',
        [user_id, email, username, password_hash, full_name]
      );

      const token = this.generateToken(user_id);

      res.status(201).json({
        message: 'User registered successfully',
        token,
        user: { id: user_id, email, username, full_name },
      });
    } catch (error) {
      res.status(500).json({ error: 'Registration failed' });
    }
  }

  async login(req: Request, res: Response) {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password required' });
      }

      const result = await this.pool.query(
        'SELECT * FROM users WHERE email = $1',
        [email]
      );

      if (result.rows.length === 0) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const user = result.rows[0];
      const passwordMatch = await bcrypt.compare(password, user.password_hash);

      if (!passwordMatch) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const token = this.generateToken(user.id);

      res.json({
        message: 'Login successful',
        token,
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          full_name: user.full_name,
        },
      });
    } catch (error) {
      res.status(500).json({ error: 'Login failed' });
    }
  }

  private generateToken(userId: string): string {
    return jwt.sign({ userId }, process.env.JWT_SECRET || 'secret', {
      expiresIn: '7d',
    });
  }
}
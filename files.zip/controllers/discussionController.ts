import { Request, Response } from 'express';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';

export class DiscussionController {
  constructor(private pool: Pool) {}

  async createDiscussion(req: Request, res: Response) {
    try {
      const { module_id, repo_id, title, description, category } = req.body;
      const creator_id = (req as any).user.userId;

      const discussion_id = uuidv4();

      await this.pool.query(
        `INSERT INTO discussions (id, module_id, repo_id, creator_id, title, description, category)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [discussion_id, module_id, repo_id, creator_id, title, description, category]
      );

      res.status(201).json({
        message: 'Discussion created successfully',
        discussion_id,
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create discussion' });
    }
  }

  async getDiscussions(req: Request, res: Response) {
    try {
      const { module_id, repo_id, category } = req.query;

      let query = 'SELECT * FROM discussions WHERE 1=1';
      const params: any[] = [];

      if (module_id) {
        query += ' AND module_id = $' + (params.length + 1);
        params.push(module_id);
      }

      if (repo_id) {
        query += ' AND repo_id = $' + (params.length + 1);
        params.push(repo_id);
      }

      if (category) {
        query += ' AND category = $' + (params.length + 1);
        params.push(category);
      }

      query += ' ORDER BY created_at DESC';

      const result = await this.pool.query(query, params);

      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch discussions' });
    }
  }

  async addReply(req: Request, res: Response) {
    try {
      const { discussion_id } = req.params;
      const { content } = req.body;
      const user_id = (req as any).user.userId;

      const reply_id = uuidv4();

      await this.pool.query(
        `INSERT INTO discussion_replies (id, discussion_id, user_id, content)
         VALUES ($1, $2, $3, $4)`,
        [reply_id, discussion_id, user_id, content]
      );

      res.status(201).json({
        message: 'Reply added successfully',
        reply_id,
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to add reply' });
    }
  }
}
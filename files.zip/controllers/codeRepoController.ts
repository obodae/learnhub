import { Request, Response } from 'express';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';

export class CodeRepoController {
  constructor(private pool: Pool) {}

  async createRepository(req: Request, res: Response) {
    try {
      const { title, description, language, visibility } = req.body;
      const owner_id = (req as any).user.userId;

      const repo_id = uuidv4();

      await this.pool.query(
        `INSERT INTO code_repositories (id, owner_id, title, description, language, visibility)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [repo_id, owner_id, title, description, language, visibility]
      );

      res.status(201).json({
        message: 'Repository created successfully',
        repo_id,
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create repository' });
    }
  }

  async getRepositories(req: Request, res: Response) {
    try {
      const { language, visibility } = req.query;

      let query = 'SELECT * FROM code_repositories WHERE visibility = $1';
      const params: any[] = [visibility || 'public'];

      if (language) {
        query += ' AND language = $' + (params.length + 1);
        params.push(language);
      }

      const result = await this.pool.query(query, params);

      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch repositories' });
    }
  }

  async uploadFile(req: Request, res: Response) {
    try {
      const { repo_id } = req.params;
      const { file_path, file_name, content, language } = req.body;

      const file_id = uuidv4();

      await this.pool.query(
        `INSERT INTO repository_files (id, repo_id, file_path, file_name, content, language)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [file_id, repo_id, file_path, file_name, content, language]
      );

      res.status(201).json({
        message: 'File uploaded successfully',
        file_id,
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to upload file' });
    }
  }

  async commitChanges(req: Request, res: Response) {
    try {
      const { repo_id } = req.params;
      const { message, changes } = req.body;
      const user_id = (req as any).user.userId;

      const commit_id = uuidv4();

      await this.pool.query(
        `INSERT INTO commits (id, repo_id, user_id, message, changes)
         VALUES ($1, $2, $3, $4, $5)`,
        [commit_id, repo_id, user_id, message, JSON.stringify(changes)]
      );

      res.status(201).json({
        message: 'Changes committed successfully',
        commit_id,
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to commit changes' });
    }
  }
}
import express from 'express';
import { ModuleController } from '../controllers/moduleController';
import { authMiddleware } from '../middleware/auth';
import { Pool } from 'pg';

const router = express.Router();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const moduleController = new ModuleController(pool);

router.post('/', authMiddleware, (req, res) => moduleController.createModule(req, res));
router.get('/', (req, res) => moduleController.getModules(req, res));
router.post('/:module_id/content', authMiddleware, (req, res) => moduleController.addLessonContent(req, res));

export default router;
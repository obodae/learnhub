import express from 'express';
import { DiscussionController } from '../controllers/discussionController';
import { authMiddleware } from '../middleware/auth';
import { Pool } from 'pg';

const router = express.Router();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const discussionController = new DiscussionController(pool);

router.post('/', authMiddleware, (req, res) => discussionController.createDiscussion(req, res));
router.get('/', (req, res) => discussionController.getDiscussions(req, res));
router.post('/:discussion_id/reply', authMiddleware, (req, res) => discussionController.addReply(req, res));

export default router;
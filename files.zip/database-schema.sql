-- Users table
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  username VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  profile_picture_url TEXT,
  bio TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_verified BOOLEAN DEFAULT FALSE
);

-- Learning Modules table
CREATE TABLE modules (
  id UUID PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  creator_id UUID NOT NULL REFERENCES users(id),
  category VARCHAR(100),
  difficulty VARCHAR(50),
  thumbnail_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_published BOOLEAN DEFAULT FALSE,
  enrollment_count INTEGER DEFAULT 0
);

-- Module Content table
CREATE TABLE module_content (
  id UUID PRIMARY KEY,
  module_id UUID NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
  lesson_number INTEGER,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  content_type VARCHAR(50),
  content_data TEXT,
  duration_minutes INTEGER,
  resources JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Module Enrollments table
CREATE TABLE module_enrollments (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  module_id UUID NOT NULL REFERENCES modules(id),
  progress_percentage INTEGER DEFAULT 0,
  completed_lessons JSONB,
  enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP
);

-- Code Repositories table
CREATE TABLE code_repositories (
  id UUID PRIMARY KEY,
  owner_id UUID NOT NULL REFERENCES users(id),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  language VARCHAR(100),
  visibility VARCHAR(50) DEFAULT 'public',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  stars_count INTEGER DEFAULT 0,
  forks_count INTEGER DEFAULT 0,
  template BOOLEAN DEFAULT FALSE
);

-- Repository Files table
CREATE TABLE repository_files (
  id UUID PRIMARY KEY,
  repo_id UUID NOT NULL REFERENCES code_repositories(id) ON DELETE CASCADE,
  file_path VARCHAR(500),
  file_name VARCHAR(255) NOT NULL,
  content TEXT,
  language VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Commits table
CREATE TABLE commits (
  id UUID PRIMARY KEY,
  repo_id UUID NOT NULL REFERENCES code_repositories(id),
  user_id UUID NOT NULL REFERENCES users(id),
  message TEXT NOT NULL,
  changes JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Discussions table
CREATE TABLE discussions (
  id UUID PRIMARY KEY,
  module_id UUID REFERENCES modules(id),
  repo_id UUID REFERENCES code_repositories(id),
  creator_id UUID NOT NULL REFERENCES users(id),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  view_count INTEGER DEFAULT 0,
  replies_count INTEGER DEFAULT 0,
  is_resolved BOOLEAN DEFAULT FALSE
);

-- Discussion Replies table
CREATE TABLE discussion_replies (
  id UUID PRIMARY KEY,
  discussion_id UUID NOT NULL REFERENCES discussions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id),
  content TEXT NOT NULL,
  is_accepted_answer BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reply_count INTEGER DEFAULT 0
);

-- Indexes for performance
CREATE INDEX idx_modules_creator ON modules(creator_id);
CREATE INDEX idx_modules_category ON modules(category);
CREATE INDEX idx_repos_owner ON code_repositories(owner_id);
CREATE INDEX idx_discussions_module ON discussions(module_id);
CREATE INDEX idx_discussions_repo ON discussions(repo_id);
CREATE INDEX idx_enrollments_user ON module_enrollments(user_id);
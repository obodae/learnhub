import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/Navbar.css';

interface NavbarProps {
  isAuthenticated: boolean;
  setIsAuthenticated: (value: boolean) => void;
}

const Navbar: React.FC<NavbarProps> = ({ isAuthenticated, setIsAuthenticated }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsAuthenticated(false);
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <Link to="/">📚 LearnHub</Link>
      </div>
      <ul className="navbar-menu">
        <li><Link to="/modules">Learning Modules</Link></li>
        <li><Link to="/repos">Code Repositories</Link></li>
        <li><Link to="/discussions">Discussions</Link></li>
        {isAuthenticated ? (
          <>
            <li><Link to="/dashboard">Dashboard</Link></li>
            <li><button onClick={handleLogout} className="logout-btn">Logout</button></li>
          </>
        ) : (
          <li><Link to="/auth" className="login-btn">Login</Link></li>
        )}
      </ul>
    </nav>
  );
};

export default Navbar;
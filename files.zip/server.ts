import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { Pool } from 'pg';

dotenv.config();

const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Middleware
app.use(cors());
app.use(express.json());

// Routes will be imported here
import authRoutes from './routes/auth';
import moduleRoutes from './routes/modules';
import codeRepoRoutes from './routes/codeRepos';
import discussionRoutes from './routes/discussions';

app.use('/api/auth', authRoutes);
app.use('/api/modules', moduleRoutes);
app.use('/api/repos', codeRepoRoutes);
app.use('/api/discussions', discussionRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`LearnHub server running on port ${PORT}`);
});

export default app;
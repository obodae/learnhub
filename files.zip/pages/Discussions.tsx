import React, { useState, useEffect } from 'react';
import { apiClient } from '../services/api';
import '../styles/Discussions.css';

interface Discussion {
  id: string;
  title: string;
  description: string;
  category: string;
  view_count: number;
  replies_count: number;
}

const Discussions: React.FC = () => {
  const [discussions, setDiscussions] = useState<Discussion[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState('');

  useEffect(() => {
    fetchDiscussions();
  }, [category]);

  const fetchDiscussions = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get('/discussions', { params: { category } });
      setDiscussions(response.data);
    } catch (error) {
      console.error('Failed to fetch discussions:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="discussions-page">
      <h1>Community Discussions</h1>

      <div className="category-filter">
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">All Categories</option>
          <option value="question">Questions</option>
          <option value="discussion">Discussions</option>
          <option value="feedback">Feedback</option>
          <option value="announcement">Announcements</option>
        </select>
      </div>

      {loading ? (
        <p>Loading discussions...</p>
      ) : (
        <div className="discussions-list">
          {discussions.map((discussion) => (
            <div key={discussion.id} className="discussion-item">
              <h3>{discussion.title}</h3>
              <p>{discussion.description}</p>
              <div className="discussion-stats">
                <span className="category">{discussion.category}</span>
                <span className="views">👁️ {discussion.view_count} views</span>
                <span className="replies">💬 {discussion.replies_count} replies</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Discussions;
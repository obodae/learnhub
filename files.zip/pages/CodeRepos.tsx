import React, { useState, useEffect } from 'react';
import { apiClient } from '../services/api';
import '../styles/CodeRepos.css';

interface Repository {
  id: string;
  title: string;
  description: string;
  language: string;
  owner_id: string;
  stars_count: number;
}

const CodeRepos: React.FC = () => {
  const [repos, setRepos] = useState<Repository[]>([]);
  const [loading, setLoading] = useState(true);
  const [language, setLanguage] = useState('');

  useEffect(() => {
    fetchRepos();
  }, [language]);

  const fetchRepos = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get('/repos', { params: { language, visibility: 'public' } });
      setRepos(response.data);
    } catch (error) {
      console.error('Failed to fetch repositories:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="repos-page">
      <h1>Code Repositories</h1>

      <div className="language-filter">
        <select value={language} onChange={(e) => setLanguage(e.target.value)}>
          <option value="">All Languages</option>
          <option value="javascript">JavaScript</option>
          <option value="typescript">TypeScript</option>
          <option value="python">Python</option>
          <option value="java">Java</option>
          <option value="go">Go</option>
        </select>
      </div>

      {loading ? (
        <p>Loading repositories...</p>
      ) : (
        <div className="repos-list">
          {repos.map((repo) => (
            <div key={repo.id} className="repo-card">
              <h3>{repo.title}</h3>
              <p>{repo.description}</p>
              <div className="repo-footer">
                <span className="language">{repo.language}</span>
                <span className="stars">⭐ {repo.stars_count}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CodeRepos;
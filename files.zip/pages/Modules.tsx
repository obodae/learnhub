import React, { useState, useEffect } from 'react';
import { apiClient } from '../services/api';
import '../styles/Modules.css';

interface Module {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  enrollment_count: number;
}

const Modules: React.FC = () => {
  const [modules, setModules] = useState<Module[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ category: '', difficulty: '' });

  useEffect(() => {
    fetchModules();
  }, [filter]);

  const fetchModules = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get('/modules', { params: filter });
      setModules(response.data);
    } catch (error) {
      console.error('Failed to fetch modules:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modules-page">
      <h1>Learning Modules</h1>

      <div className="filters">
        <select value={filter.category} onChange={(e) => setFilter({ ...filter, category: e.target.value })}>
          <option value="">All Categories</option>
          <option value="web">Web Development</option>
          <option value="mobile">Mobile Development</option>
          <option value="data">Data Science</option>
          <option value="devops">DevOps</option>
        </select>

        <select value={filter.difficulty} onChange={(e) => setFilter({ ...filter, difficulty: e.target.value })}>
          <option value="">All Levels</option>
          <option value="beginner">Beginner</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanced">Advanced</option>
        </select>
      </div>

      {loading ? (
        <p>Loading modules...</p>
      ) : (
        <div className="modules-grid">
          {modules.map((module) => (
            <div key={module.id} className="module-card">
              <h3>{module.title}</h3>
              <p>{module.description}</p>
              <div className="module-meta">
                <span className="category">{module.category}</span>
                <span className="difficulty">{module.difficulty}</span>
                <span className="enrollment">{module.enrollment_count} enrolled</span>
              </div>
              <button className="enroll-btn">Enroll Now</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Modules;
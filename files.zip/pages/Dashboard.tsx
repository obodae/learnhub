import React, { useState, useEffect } from 'react';
import { apiClient } from '../services/api';
import '../styles/Dashboard.css';

const Dashboard: React.FC = () => {
  const [enrolledModules, setEnrolledModules] = useState([]);
  const [userRepos, setUserRepos] = useState([]);
  const [stats, setStats] = useState({ courses: 0, repos: 0, discussions: 0 });

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [modulesRes, reposRes] = await Promise.all([
        apiClient.get('/user/enrolled-modules'),
        apiClient.get('/user/repositories'),
      ]);

      setEnrolledModules(modulesRes.data);
      setUserRepos(reposRes.data);
      setStats({
        courses: modulesRes.data.length,
        repos: reposRes.data.length,
        discussions: 0,
      });
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    }
  };

  return (
    <div className="dashboard">
      <h1>Your Dashboard</h1>

      <div className="stats-grid">
        <div className="stat-card">
          <h3>{stats.courses}</h3>
          <p>Courses Enrolled</p>
        </div>
        <div className="stat-card">
          <h3>{stats.repos}</h3>
          <p>Repositories</p>
        </div>
        <div className="stat-card">
          <h3>{stats.discussions}</h3>
          <p>Discussions</p>
        </div>
      </div>

      <section className="dashboard-section">
        <h2>Your Enrolled Courses</h2>
        <div className="courses-list">
          {enrolledModules.map((module: any) => (
            <div key={module.id} className="course-item">
              <h4>{module.title}</h4>
              <div className="progress-bar">
                <div className="progress" style={{ width: `${module.progress_percentage}%` }}></div>
              </div>
              <span>{module.progress_percentage}% Complete</span>
            </div>
          ))}
        </div>
      </section>

      <section className="dashboard-section">
        <h2>Your Repositories</h2>
        <div className="repos-list">
          {userRepos.map((repo: any) => (
            <div key={repo.id} className="repo-item">
              <h4>{repo.title}</h4>
              <p>{repo.description}</p>
              <span className="language">{repo.language}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
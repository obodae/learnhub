import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Home.css';

const Home: React.FC = () => {
  return (
    <div className="home">
      <section className="hero">
        <h1>Welcome to LearnHub</h1>
        <p>A collaborative platform for learning, coding, and sharing knowledge</p>
        <Link to="/modules" className="cta-button">Start Learning</Link>
      </section>

      <section className="features">
        <div className="feature-card">
          <h3>📖 Learning Modules</h3>
          <p>Structured courses created by the community with lessons, quizzes, and resources.</p>
        </div>
        <div className="feature-card">
          <h3>💻 Code Repositories</h3>
          <p>Share and collaborate on code projects with version control and commits.</p>
        </div>
        <div className="feature-card">
          <h3>💬 Discussions</h3>
          <p>Ask questions, share feedback, and engage with the learning community.</p>
        </div>
        <div className="feature-card">
          <h3>👥 Collaborate</h3>
          <p>Learn together, review code, and grow your skills with peers.</p>
        </div>
      </section>
    </div>
  );
};

export default Home;
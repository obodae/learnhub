# LearnHub - Collaborative Learning Platform

A modern platform for learning, coding, and sharing knowledge in a collaborative environment.

## Features

- 📖 **Learning Modules**: Structured courses with lessons, quizzes, and resources
- 💻 **Code Repositories**: Share and collaborate on code projects with version control
- 💬 **Discussions**: Community-driven Q&A and feedback
- 👥 **User Profiles**: Showcase your learning journey and contributions
- 🔐 **Secure Authentication**: JWT-based authentication

## Tech Stack

- **Frontend**: React + TypeScript
- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL
- **Containerization**: Docker & Docker Compose

## Installation

### Prerequisites
- Node.js (v16+)
- PostgreSQL (v12+)
- Docker & Docker Compose

### Quick Start with Docker

```bash
docker-compose up --build